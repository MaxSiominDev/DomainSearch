package dev.maxsiomin.qr.fragments.history

import dagger.hilt.android.AndroidEntryPoint
import dev.maxsiomin.qr.R
import dev.maxsiomin.qr.databinding.FragmentHistoryBinding
import dev.maxsiomin.qr.fragments.base.BaseFragment

@AndroidEntryPoint
class HistoryFragment : BaseFragment(R.layout.fragment_history) {

    private lateinit var binding: FragmentHistoryBinding

    override val mRoot get() = binding.root
}
