package dev.maxsiomin.qr.util

import android.os.Bundle
import androidx.fragment.app.Fragment
import dev.maxsiomin.qr.activity.MainActivity

typealias StringSharedDataKey = SharedDataKey<String>

const val SHARED_DATA = "sharedData"

/**
 * Lets fragment save data in activity
 */
interface SharedData {

    fun getSharedString(key: StringSharedDataKey): String?

    fun putSharedString(key: StringSharedDataKey, value: String?)

    fun toBundle(): Bundle
}

class SharedDataImpl(bundle: Bundle?) : SharedData {

    private val sharedBundle: Bundle = bundle ?: Bundle()

    override fun getSharedString(key: StringSharedDataKey): String? =
        sharedBundle.getString(key.value)

    override fun putSharedString(key: StringSharedDataKey, value: String?) {
        if (value == null)
            sharedBundle.remove(key.value)
        else
            sharedBundle.putString(key.value, value)
    }

    override fun toBundle(): Bundle = sharedBundle
}

@Suppress("unused")
data class SharedDataKey <T> (
    val value: String,
)

object SharedDataKeys {

    val EMAIL = StringSharedDataKey("email")
    val PASSWORD = StringSharedDataKey("password")

    val QR_CODE_TEXT = StringSharedDataKey("qrCodeText")
}
