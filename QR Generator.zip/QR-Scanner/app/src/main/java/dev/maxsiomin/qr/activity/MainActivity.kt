package dev.maxsiomin.qr.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.AndroidEntryPoint
import dev.maxsiomin.qr.R
import dev.maxsiomin.qr.util.SHARED_DATA
import dev.maxsiomin.qr.util.SharedData
import dev.maxsiomin.qr.util.SharedDataImpl

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    lateinit var analytics: FirebaseAnalytics

    lateinit var sharedData: SharedData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        analytics = Firebase.analytics

        sharedData = SharedDataImpl(savedInstanceState?.getBundle(SHARED_DATA))
    }
}
