package dev.maxsiomin.qr.fragments.signup

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import dev.maxsiomin.qr.R
import dev.maxsiomin.qr.databinding.FragmentSignupBinding
import dev.maxsiomin.qr.extensions.clearError
import dev.maxsiomin.qr.extensions.sharedData
import dev.maxsiomin.qr.extensions.toEditable
import dev.maxsiomin.qr.fragments.base.BaseFragment
import dev.maxsiomin.qr.util.Email
import dev.maxsiomin.qr.util.PASSWORD_MIN_LENGTH
import dev.maxsiomin.qr.util.Password
import dev.maxsiomin.qr.util.SharedDataKeys.EMAIL
import dev.maxsiomin.qr.util.SharedDataKeys.PASSWORD
import javax.inject.Inject

@AndroidEntryPoint
class SignupFragment : BaseFragment(R.layout.fragment_signup) {

    private lateinit var binding: FragmentSignupBinding

    override val mRoot get() = binding.root

    private val mViewModel by viewModels<SignupViewModel>()

    @Inject
    lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentSignupBinding.inflate(layoutInflater, container, false)

        with (binding) {
            sharedData.getSharedString(EMAIL)?.let {
                emailEditText.text = it.toEditable()
            }

            sharedData.getSharedString(PASSWORD)?.let {
                passwordEditText.text = it.toEditable()
            }

            loginTextView.setOnClickListener { findNavController().popBackStack() }

            signupButton.setOnClickListener {
                val email = Email(emailEditText.text)
                val password = Password(passwordEditText.text)
                val confirmedPassword = Password(confirmPasswordEditText.text)

                when {
                    !email.isCorrect -> {
                        emailEditTextLayout.error = getString(R.string.invalid_email)
                        emailEditText.requestFocus()
                    }

                    !password.isStrong -> {
                        passwordEditTextLayout.error = getString(R.string.weak_password, PASSWORD_MIN_LENGTH)
                        passwordEditText.requestFocus()
                    }

                    confirmedPassword != password -> {
                        confirmPasswordEditTextLayout.error = getString(R.string.passwords_not_match)
                    }

                    else -> {
                        mViewModel.signup(email, password, auth) {
                            auth.signInWithEmailAndPassword(email.value, password.value).addOnCompleteListener {
                                //loginActivity.onSignup()
                            }
                        }
                    }
                }
            }

            emailEditText.addTextChangedListener {
                emailEditTextLayout.clearError()
            }

            passwordEditText.addTextChangedListener {
                passwordEditTextLayout.clearError()
            }

            confirmPasswordEditText.addTextChangedListener {
                confirmPasswordEditTextLayout.clearError()
            }
        }

        return binding.root
    }

    override fun onStop() {
        sharedData.putSharedString(EMAIL, binding.emailEditText.text?.toString())
        sharedData.putSharedString(PASSWORD, binding.passwordEditText.text?.toString())
        super.onStop()
    }
}
