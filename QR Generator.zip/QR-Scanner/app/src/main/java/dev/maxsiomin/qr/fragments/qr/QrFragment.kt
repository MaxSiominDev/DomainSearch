package dev.maxsiomin.qr.fragments.qr

import android.os.Bundle
import android.view.View
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.journeyapps.barcodescanner.BarcodeEncoder
import dev.maxsiomin.qr.R
import dev.maxsiomin.qr.databinding.FragmentQrBinding
import dev.maxsiomin.qr.fragments.base.BaseFragment

class QrFragment : BaseFragment(R.layout.fragment_qr) {

    private lateinit var binding: FragmentQrBinding

    override val mRoot get() = binding.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentQrBinding.bind(view)

        setupQrCode()
    }

    private fun setupQrCode() {
        val qrCodeText: String = requireArguments().getString(ARG_QR_CODE_TEXT)!!
        val size = resources.getDimension(R.dimen.qr_size).toInt()

        val matrix = MultiFormatWriter().encode(qrCodeText, BarcodeFormat.QR_CODE, size, size)
        binding.qrImage.setImageBitmap(BarcodeEncoder().createBitmap(matrix))
    }

    companion object {
        const val ARG_QR_CODE_TEXT = "QrCodeText"
    }
}
