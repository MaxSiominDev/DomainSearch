package dev.maxsiomin.qr.extensions

import android.text.SpannableStringBuilder

fun String.toEditable() = SpannableStringBuilder(this)
